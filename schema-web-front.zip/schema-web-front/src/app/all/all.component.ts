import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Schema } from '../models/schema';
import { SchemaService } from '../services/schema.service';

@Component({
  selector: 'app-all',
  templateUrl: './all.component.html',
  styleUrls: ['./all.component.scss']
})
export class AllComponent implements OnInit {
  elementData: Schema[] = [];
  displayedColumns: string[] = ['name', 'id', 'view'];
  dataSource = new MatTableDataSource(this.elementData);

  constructor(private schemaService: SchemaService) { }

  ngOnInit() {
    this.schemaService.getUserSchemasList().subscribe(x => {
      this.elementData = x;
      this.dataSource.data = this.elementData;
    }, err => {
      console.log(err);
    });
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
