import { Component, OnInit } from '@angular/core';
import { User } from '../models/schema';
import { UserService } from '../services/user.service';
import { SchemaService } from '../services/schema.service';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  user: User;

  constructor(private userService: UserService, private sechemaService: SchemaService) { }

  ngOnInit() {
    this.userService.getUser().subscribe(u => {
      this.user = u;
      console.log(this.user);
    });
  }

  downloadXML() {
    this.sechemaService.downloadXML().subscribe(schema => {
      saveAs(schema, this.user.username + '.xml');
    }, err => {
      console.log(err);
    });
  }

  downloadOntology() {
    this.sechemaService.downloadRDF().subscribe(schema => {
      saveAs(schema, this.user.username + '.rdf');
    }, err => {
      console.log(err);
    });
  }

  downloadLastSchema() {
    this.sechemaService.downloadHTML().subscribe(schema => {
      saveAs(schema, this.user.username + '.html');
    }, err => {
      console.log(err);
    });
  }
}
