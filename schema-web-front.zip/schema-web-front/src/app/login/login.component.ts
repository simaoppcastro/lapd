import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  login: FormGroup;

  constructor(private formBuilder: FormBuilder, private userService: UserService, private router: Router) { }

  ngOnInit() {
    this.login = this.formBuilder.group({
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required]),
    });
  }

  onSubmit() {
    if (this.login.invalid) {
      return;
    }

    this.userService.login(this.login.value).subscribe(x => {
      if (x.status === 0) {
        localStorage.setItem('currentUser', x.jwt);
        this.router.navigate(['/main']);
      } else {
        console.log('Error...');
      }
    }, err => {
      console.log(err);
    });
  }

  get email() { return this.login.get('email'); }
  get password() { return this.login.get('password'); }

}
