import { Schema } from './schema';

describe('Schema', () => {
  it('should create an instance', () => {
    expect(new Schema()).toBeTruthy();
  });
});
