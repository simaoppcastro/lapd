export class Schema {
  name?: string;
  id?: string;
  attrs?: Attributes[];
}

export class Attributes {
  name?: string;
  type?: string;
  value?: string;
}

export class User {
  username?: string;
  email?: string;
}
