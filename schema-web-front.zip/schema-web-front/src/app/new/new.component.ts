import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators, FormArray } from '@angular/forms';
import { startWith, map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { SchemaService } from '../services/schema.service';
import { Schema } from '../models/schema';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.scss']
})
export class NewComponent implements OnInit {
  newSchema: FormGroup;
  attrsArray: FormArray;

  schemasList: string[] = [];
  filteredSchemas: Observable<string[]>;

  attrsList: string[] = [];

  types: string[];
  constructor(private formBuilder: FormBuilder, private schemaService: SchemaService, private router: Router) {
  }

  ngOnInit() {
    this.schemaService.getSchemaList().subscribe(list => {
      this.schemasList = list;
    }, err => {
      console.log(err);
    });

    this.types = ['char', 'String', 'Number', 'Boolean', 'Date'];

    this.newSchema = this.formBuilder.group({
      name: new FormControl('', [Validators.required]),
      id: new FormControl('', [Validators.required]),
      attrs: this.formBuilder.array([
        this.createItem()
      ])
    });

    this.filteredSchemas = this.name.valueChanges
    .pipe(
      startWith(''),
      map(value => this._filterSchemas(value))
    );
  }

  private _filterSchemas(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.schemasList.filter(option => option.toLowerCase().includes(filterValue));
  }

  createItem(): FormGroup {
    return this.formBuilder.group({
      name: new FormControl(null, [Validators.required]),
      type: new FormControl(null, [Validators.required]),
      value: new FormControl(null, [Validators.required])
    });
  }

  addItem(): void {
    this.attrsArray = this.attrs as FormArray;
    this.attrsArray.push(this.createItem());
  }

  removeItem(index: number): void {
    this.attrsArray = this.attrs as FormArray;
    this.attrsArray.removeAt(index);
  }

  onSubmit() {
    if (this.newSchema.invalid) {
      return;
    }

    const schema: Schema = {
      name: this.name.value,
      id: this.id.value,
      attrs: []
    };

    this.attrsList.forEach(attr => {
      const index = this.attrs.value.findIndex(x => x.name === attr);

      if (index < 0) {
        schema.attrs.push({
          name: attr,
          type: null,
          value: null
        });
      } else {
        schema.attrs.push(this.attrs.value[index]);
      }
    });

    this.schemaService.createSchema(schema).subscribe(x => {
      console.log(x);
      if (x.status === 0) {
        this.router.navigate(['/main/schema', schema.name, schema.id]);
      }
    }, err => {
      console.log(err);
    });
  }

  onSchemaChange(schema: string) {
    if (schema === null || schema === undefined || schema === '') {
      return;
    }

    this.schemaService.getAttrsList(schema).subscribe(list => {
      this.attrsList = list;
    }, err => {
      console.log(err);
    });
  }

  get name() { return this.newSchema.get('name'); }
  get id() { return this.newSchema.get('id'); }
  get attrs() { return this.newSchema.get('attrs') as FormArray; }
}
