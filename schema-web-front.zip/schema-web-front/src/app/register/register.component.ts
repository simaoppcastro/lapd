import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  register: FormGroup;

  constructor(private formBuilder: FormBuilder, private userService: UserService, private router: Router) { }

  ngOnInit() {
    this.register = this.formBuilder.group({
      username: new FormControl('', [Validators.required]),
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required]),
      rpassword: new FormControl('', [Validators.required])
    }, {validator: this.checkPasswords });
  }

  checkPasswords(group: FormGroup) { // here we have the 'passwords' group
    const pass = group.get('password').value;
    const confirmPass = group.get('rpassword').value;

    return pass === confirmPass ? null : { notSame: true };
  }

  onSubmit() {
    if (this.register.invalid) {
      return;
    }

    this.userService.createUser(this.register.value).subscribe(x => {
      if (x.status === 0) {
        this.router.navigate(['/login']);
      } else {
        console.log('Error...');
      }
    }, err => {
      console.log(err);
    });
  }

  get username() { return this.register.get('username'); }
  get email() { return this.register.get('email'); }
  get password() { return this.register.get('password'); }
  get rpassword() { return this.register.get('rpassword'); }
}
