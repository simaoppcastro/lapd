import { Component, OnInit } from '@angular/core';
import { Schema } from '../models/schema';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { SchemaService } from '../services/schema.service';

@Component({
  selector: 'app-schema',
  templateUrl: './schema.component.html',
  styleUrls: ['./schema.component.scss']
})
export class SchemaComponent implements OnInit {
  schema: Schema = {};
  displayedColumns: string[] = ['name', 'type', 'value'];
  dataSource = new MatTableDataSource(this.schema.attrs);

  constructor(private route: ActivatedRoute, private schemaService: SchemaService) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.schema.name = params.get('name');
      this.schema.id = params.get('id');

      this.schemaService.getUserSchema(params.get('name'), params.get('id')).subscribe(x => {
        this.schema.attrs = x;
        this.dataSource.data = this.schema.attrs;
      }, err => {
        console.log(err);
      });

    });
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}
