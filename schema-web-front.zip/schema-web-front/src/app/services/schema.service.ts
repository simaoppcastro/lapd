import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Schema, Attributes } from '../models/schema';

@Injectable({
  providedIn: 'root'
})
export class SchemaService {
  private url = 'http://localhost:5000/apiSchema';

  constructor(private http: HttpClient) { }

  getSchemaList(): Observable<string[]> {
    return this.http.get<any>(this.url + '/getSchemaNameList');
  }

  getAttrsList(schema: string): Observable<string[]> {
    return this.http.get<any>(this.url + '/getAttrsNameList/' + schema);
  }

  createSchema(schema: Schema): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    return this.http.post(this.url + '/createSchema', schema, httpOptions);
  }

  getUserSchema(schemaName: string, schemaId: string): Observable<Attributes[]> {
    return this.http.get<Attributes[]>(this.url + '/getUserSchema/' + schemaName + '/' + schemaId);
  }

  getUserSchemasList(): Observable<Schema[]> {
    return this.http.get<Schema[]>(this.url + '/getUserSchemas');
  }

  downloadXML(): Observable<Blob> {
    return this.http.get<Blob>(this.url + '/downloadXML', {responseType: 'blob' as 'json'});
  }

  downloadRDF(): Observable<Blob> {
    return this.http.get<Blob>(this.url + '/downloadRDF', {responseType: 'blob' as 'json'});
  }

  downloadHTML(): Observable<Blob> {
    return this.http.get<Blob>(this.url + '/downloadHTML', {responseType: 'blob' as 'json'});
  }
}
