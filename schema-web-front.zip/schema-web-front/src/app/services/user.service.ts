import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private url = 'http://localhost:5000/apiUser';

  constructor(private http: HttpClient) { }

  createUser(user: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    return this.http.post(this.url + '/register-user', user, httpOptions);
  }

  login(user: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    return this.http.post(this.url + '/login', user, httpOptions);
  }

  getUser(): Observable<any> {
    return this.http.get<any>(this.url + '/getUser');
  }

  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('currentUser');
  }

  isAuthenticated(): boolean {
    const user = localStorage.getItem('currentUser');
    if (user) {
      return true;
    } else {
      return false;
    }
  }

  getToken(): string {
    let token;

    if (localStorage.getItem('currentUser')) {
      token = 'Bearer ' + localStorage.getItem('currentUser');
    } else {
      token = 'Bearer ';
    }

    return token;
  }
}
