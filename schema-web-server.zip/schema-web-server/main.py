
import mysql.connector
from lxml import etree as et
import os
import xml.etree.ElementTree as ET
import utils_LAPD as ut


def mysql(data_in):
    # Escreve na BD status
    mydb = mysql.connector.connect(host="localhost", user="root", passwd='', database="comprotocol")
    mycusor = mydb.cursor()
    sql = "INSERT INTO db_comprocol (ip, cpu, mem, net) VALUES (%s, %s, %s, %s)"
    parametros = (data_in["ip"], data_in["cpu"], data_in["mem"], data_in["net"])


    mycusor.execute(sql, parametros)
    mydb.commit()
    print
    'JSON introduzido na BD e no ficheiro .json com sucesso!'

def main():
    CompleteList_schema = ut.main_core()

    # example to get all of the objects
    GET = ut.GET()
    xml = GET.GetXML(CompleteList_schema)
    dict = GET.GetDICT(CompleteList_schema)
    Properties = GET.GetPropertiesLIST(CompleteList_schema)
    Values = GET.GetValuesLIST(CompleteList_schema)

    # print(dict)
    # print(xml)
    # debug
    # ut.xmlControl()

    # ATENÇÃO ADICIONAR FUNCIONALIDADE PARA ADICIONAR CAMPO DE POR EXEMPLO QUANDO UTILIZADOR ESCOLHE
    # MOVIE, CONSEGUIR ESCOLHER LOGO NO INICIO QUAL O NOME DESSE MESMO MOVIE, OU SEJA, ADICIONAR NO XML <MOVIE id = 'Avatar'></MOVIE>
    # implementado, em testes

    return GET


if __name__ == '__main__':
    main()




