from owlready2 import *
from lxml import etree
import xml.etree.ElementTree as ET
from ontology.sdk import Ontology
import os
import shutil
import xmlschema
import utils_LAPD as ut
from lxml import etree
import lxml.html as lh
import ontospy
# from ontospy.ontodocs.viz.viz_html_single import *

import sys
from rdflib import Graph, URIRef
# from gastrodon import LocalEndpoint, one, QName
# import gzip
import pandas as pd


# utils already
# to create the xsl/xslt file
def htmlRuler_generator(userInput, schemaInput):
    rulerMaster = "UserSchema/XSLstyleSheetRules.xsl"
    h2Title = '    <h2>' + userInput + "_" + schemaInput + '</h2>\n'
    h2Comp = '    <h2>Schema</h2>\n'
    foreachSelector = "      <xsl:for-each select = '" + userInput + "/" + schemaInput + "/*'" + ">\n"
    foreachComp = '      <xsl:for-each select="Simao/Person/*">\n'
    outputXSLfile = "UserSchema/" + userInput + ".xsl"

    # debug
    # print(rulerMaster)
    # print(h2Title)
    # print(foreachSelector)
    # print(foreachComp)

    with open(rulerMaster, 'r') as f:
        content = f.readlines()
        # print(content)
        # print(type(content))
        for line in content:
            # print(line)
            if line == foreachComp:
                # print("True")
                content[content.index(line)] = foreachSelector
            elif line == h2Comp:
                content[content.index(line)] = h2Title

        # print(content)

    with open(outputXSLfile, "w+") as fo:
        fo.writelines(content)

# utils already
# to create the html file
def XHTML_generator(userInput, schemaInput):
    # tree = ET
    # first create the xsl from the ruler base
    htmlRuler_generator(userInput, schemaInput)
    path_xml = "UserSchema/" + userInput + ".xml"
    path_xslt = "UserSchema/" + userInput + ".xsl"


    dom = etree.parse(path_xml)
    xslt = etree.parse(path_xslt)
    transform = etree.XSLT(xslt)
    html = transform(dom)
    # debug
    # tree.parse(etree.tostring(html, pretty_print=True))
    # print(etree.tostring(html, pretty_print=True))
    # etree.write(etree.tostring(newdom, pretty_print=True))

    outputHtml = "UserSchema/" + userInput + ".html"
    html.write(outputHtml, encoding='utf-8', pretty_print=True, xml_declaration=True)

# utils already
# from xml and xslt, generate RDF file
def xml_xslt2rdf(userInput):
    path_xml = "UserSchema/" + userInput + ".xml"
    path_xslt = "UserSchema/rulerXML2RDF" + ".xslt"

    dom = etree.parse(path_xml)
    xslt = etree.parse(path_xslt)
    transform = etree.XSLT(xslt)
    rdf = transform(dom)
    # debug
    # tree.parse(etree.tostring(html, pretty_print=True))
    # print(etree.tostring(html, pretty_print=True))
    # etree.write(etree.tostring(newdom, pretty_print=True))

    outputRDF = "UserSchema/" + userInput + ".rdf"
    rdf.write(outputRDF, encoding='utf-8', pretty_print=True)


def xlst(xmlInput):
    print()

# confirm if works (not ready wet)
# DTD validator
# DTD not used -> XMLSchema instead
def xml2dtd_validator(xmlInput, xsdInput):
    try:
        # this method will validate xml file trow the dtd especifief
        parser = etree.XMLParser(dtd_validation=True)
        tree = etree.parse(xmlInput, parser)
        print("XML/DTD Validated!")
    except:
        print("XML/DTD Not Validated!")

# to validate xml xsd files
# https://www.freeformatter.com/xml-validator-xsd.html
def xml2xsd_validator(xmlInput, xsdInput):
    # schema_file = StringIO(xsdInput)
    schema_doc = etree.parse(xsdInput)
    xmlschema = etree.XMLSchema(schema_doc)

    # xml_file = open(xmlInput)
    xml = etree.parse(xmlInput)

    xmlschema.validate(xml)

# not used
# not ready wet
def ontologies_generator(fileInput, userInput):
    # onto = get_ontology(fileInput).load()
    # onto_path.append("xml/testes")
    onto = get_ontology(fileInput).load()

    fileOutput = "UserSchema/" + str(userInput) + ".rdf"
    print(fileOutput)
    onto.save(file=fileOutput, format="rdfxml")
    # onto.save()

# tentative to visualize the rdf/ontology
def rdf_visual(userInput):
    rdfInput = "UserSchema/" + userInput + ".xml"

    pd.set_option("display.width", 100)
    pd.set_option("display.max_colwidth", 80)

    g = Graph()
    g.parse(rdfInput)
    # e = LocalEndpoint(g)
    '''properties = e.select("""
           SELECT ?p (COUNT(*) AS ?cnt) {
              ?s ?p ?o .
              FILTER(?s!=?_ontology)
           } GROUP BY ?p ORDER BY DESC(?cnt)
        """)

    properties["cnt"].plot.pie(figsize=(6, 6)).set_ylabel('')'''


# read xml file, and get every schema that the specifc user have
# return List of list with schema and ID, from the specific user
def readXML_get_SchemaID(userInput):
    parser = etree.XMLParser(remove_blank_text=True)
    xml = "UserSchema/" + userInput + ".xml"
    src = etree.parse(xml, parser)
    root = src.getroot()

    schemaList = []

    value2Remove1 = "{'ID': '"
    value2Remove2 = "'}"

    for child in root:
        schema = str(child.tag)
        id = str(child.attrib)
        id = id.replace(value2Remove1, '')
        id = id.replace(value2Remove2, '')
        schemaList.append([schema, id])
        # print(schema, id)

    # return Dict with schema (key) and ID (value)
    return schemaList

# read xml file, and get every schema that the specifc user have
# return list of every schema from the specific user
def readXML_get_Schema(userInput):
    parser = etree.XMLParser(remove_blank_text=True)
    xml = "UserSchema/" + userInput + ".xml"
    src = etree.parse(xml, parser)
    root = src.getroot()

    schemaList = []
    for child in root:
        # print(child.tag)
        schemaList.append(child.tag)

    return schemaList

# pass to the function, user, id and schema that you want
# and the function returns one dict with key = propertie and value = [type, value]
def getContent_schemaId(userInput, idInput, schmaInput):
    list = readXML_get_SchemaID(userInput)
    Dict = {}
    flag = False
    for element1 in list:
       # print(element1[0], element1[1])
       if element1[0] == schmaInput and element1[1] == idInput:
           schema = element1[0]
           id = element1[1]
           flag = True
           break

    #print(schema, id, flag)
    value2Remove1 = "{'ID': '"
    value2Remove2 = "'}"

    if flag:
        # print(schema, id)
        parser = etree.XMLParser(remove_blank_text=True)
        xml = "UserSchema/" + userInput + ".xml"
        src = etree.parse(xml, parser)
        root = src.getroot()

        for child in root:
            temp = str(child.attrib)
            temp = temp.replace(value2Remove1, '')
            temp = temp.replace(value2Remove2, '')
            if (str(child.tag) == schema) and (temp == id):
                for element in child:
                    prop = str(element.tag)
                    type = str(element.attrib)
                    type = type.replace("{'type': '", '')
                    type = type.replace("'}", '')
                    value = str(element.text)
                    # debug
                    # print(prop, type, value)
                    Dict[prop] = [type, value]

    return Dict

# main tests
def main():
    fileInput = "UserSchema/Simao.xml"
    userInput = "Simao"
    ontologies_generator(fileInput, userInput)

    # xml2dtd_validator()


def teste(userInput):
    path_xml = "UserSchema/" + userInput + ".xml"
    path_xslt = "Tests/xml2rdf3" + ".xsl"

    dom = etree.parse(path_xml)
    xslt = etree.parse(path_xslt)
    transform = etree.XSLT(xslt)
    rdf = transform(dom)
    # debug
    # tree.parse(etree.tostring(html, pretty_print=True))
    # print(etree.tostring(html, pretty_print=True))
    # etree.write(etree.tostring(newdom, pretty_print=True))

    outputRDF = "Tests/" + userInput + "testeRDF.rdf"
    rdf.write(outputRDF, encoding='utf-8', pretty_print=True)

if __name__ == '__main__':
    # main()

    # CSVresult = ut.openCSVfile('schema_csv/schema-types.csv', 'idNumber', 'label', 'properties')
    # print(CSVresult)
    # ListType = ut.GetCompleteLabel(CSVresult, "Person")
    # PropertiesList = ut.GetProperties(CSVresult, ListType[0])
    # for p in PropertiesList:
    #     print(p)

    userInput = "Simao"
    # xml2xsd("Filipe")
    # xml2dtd_validator("UserSchema/Abilio.xml", "UserSchema/Abilio.xsd")

    # debug
    # print(xmlSchemaDec)
    # nameSpaceDeclaration(userInput)
    # ut.nameSpaceDeclaration(userInput)
    # XHTML_generator(userInput, "MovieClip")
    # xml_xslt2rdf(userInput)
    # rdf_visual(userInput)
    # print(readXML_get_SchemaID(userInput))
    # print(type(readXML_getSchema_ID(userInput)))
    # dict = getContent_schemaId(userInput, "Sppc", "Person")
    # print(dict)
    # print(ut.ConfirmDir("UserSchema/Simao.html"))
    teste(userInput)