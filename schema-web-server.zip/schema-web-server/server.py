from flask import Flask, request, send_file, render_template, send_from_directory, make_response
from flask_cors import CORS, cross_origin
import mysql.connector as mariadb
import json
import hashlib
import calendar
from datetime import datetime
import jwt
import utils_LAPD as ut
import pathlib

jwtSecrete = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'

mydb= mariadb.connect(user='root', password='', database='lapd')
mydb.autocommit = True

app = Flask(__name__)
cors = CORS(app)

#=== USER =================
@app.route('/apiUser/register-user', methods=['POST'])
def registerUser():
    u = request.get_json()
    u['password'] = hash(u['password'].encode('utf-8'))
    cursor = mydb.cursor()
    sql = "INSERT INTO users (user_name, email, password) VALUES (%s, %s, %s)"
    val = (u['username'], u['email'], u['password'])
    
    try:
        cursor.execute(sql, val)
    except Exception as e:
        return '{"status": -1, "message":"' + str(e) + '"}'

    return '{"status": 0, "message":""}'

@app.route('/apiUser/login', methods=['POST'])
def loginUser():
    u = request.get_json()
    u['password'] = hash(u['password'].encode('utf-8'))
    cursor = mydb.cursor()
    sql = "SELECT id FROM users WHERE email = %s AND password = %s"
    val = (u['email'], u['password'],)
    try:
        cursor.execute(sql, val)
        user = cursor.fetchone()
    except Exception as e:
        return '{"status": -1, "message":"' + str(e) + '"}'
    return '{"status": 0, "jwt":"' + bytes(CreateJWT(user[0])).decode("utf-8") + '"}'

@app.route('/apiUser/getUser', methods=['GET'])
def getUser():
    user = ValidateJWT()
    if user == None: 
        return '{"status": -1, "message": "not authorized"}', 401
    
    cursor = mydb.cursor()
    cursor.execute("SELECT email, user_name from users where id=" + str(user['userId']))
    result = cursor.fetchone()
    
    return '{"email":"' + result[0] + '", "username":"' + result[1] + '"}'



#=== SCHEMA ================
@app.route('/apiSchema/createSchema', methods=['POST'])
def createSchema():
    user = ValidateJWT()
    if user == None: 
        return '{"status": -1, "message": "not authorized"}', 401

    cursor = mydb.cursor()
    cursor.execute("SELECT user_name, id from users where id=" + str(user['userId']))
    result=cursor.fetchone()
    schema = request.get_json()

    if (schemaExist(schema['id'], result[0])):
        return '{"status": -1, "message": "this id already exist..."}', 400

    attrs = {}
    types = []

    for attr in schema['attrs']:
        attrs.update({attr['name']: attr['value']})
        types.append(attr['type'])

    fileTemp = "xml/schema_" + result[0] + "_" +schema['name'] + ".xml"
    finalFile = "UserSchema/" + result[0] + ".xml"

    ut.Dict_to_XML(attrs, result[0], schema['name'], types)
    ut.addID2Schema(schema['id'], fileTemp, schema['name'])
    ut.addChangeType2XML(types, fileTemp)

    try:
        # path_final = 'xml/UserSchema/' + userInput + '.xml'
        ut.xml2xml(fileTemp, finalFile)
    except:
        print("Error! xml2xml()")

    # to insert typeDock declaration (DTD validation)
    typeDock = "<!DOCTYPE " + result[0] + " SYSTEM " + "'schemaDTD.dtd'>"
    # xmlSchemaDec = "xmlns:xsi = 'http://www.w3.org/2001//XMLSchema-instance' xsi:noNamespaceSchemaLocation = '" + userInput + ".xsd'>"
    # debug
    # print(xmlSchemaDec)

    # to add docktype declaration (DTD)
    try:
        # debug
        # print()
        # return bool
        flag_dock = ut.dockTypeInsert(result[0], finalFile, typeDock)
    except:
        return '{"status": -1, "message": "erro dock_type_insert"}'

    # to add the XML Schema declaration to the root element
    if flag_dock:
        try:
            # XML Schema file creation (return bool)
            flag_nameSpace = ut.nameSpaceDeclaration(result[0])
        except:
            return '{"status": -1, "message": "error name_space_declaration"}'

    # to create the XML Schema (.xsd file)
    if flag_nameSpace:
        try:
            ut.xml2xsd(result[0])
        except:
            return '{"status": -1, "message": "error xml2xsd"}'

    # first generates the xsl/xslt file
    # second generates the html page with the content from the current user, and
    # the values for the specific schema with all the properties
    # and values
    ut.XHTML_generator(result[0], schema['name'])
    # from one xml and xslt file, generates a rdf file
    ut.xml_xslt2rdf(result[0])

    return '{"status": 0, "message": "ok"}'

@app.route('/apiSchema/getSchemaNameList', methods=['GET'])
def getSchemaNameList():
    user = ValidateJWT()
    if user == None: 
        return '{"status": -1, "message": "not authorized"}', 401

    schemas = ut.GetSchemaList('schema_csv/schema-types.csv', 'idNumber', 'label', 'properties')
    return json.dumps(schemas)

@app.route('/apiSchema/getAttrsNameList/<schema>', methods=['GET'])
def getAttrs(schema):
    user = ValidateJWT()
    if user == None: 
        return '{"status": -1, "message": "not authorized"}', 401


    CSVresult = ut.openCSVfile('schema_csv/schema-types.csv', 'idNumber', 'label', 'properties')
    attrs = ut.GetProperties(CSVresult, schema)
    return json.dumps(attrs)

@app.route('/apiSchema/downloadXML')
def downloadXML():
    user = ValidateJWT()
    if user == None: 
        return '{"status": -1, "message": "not authorized"}', 401

    cursor = mydb.cursor()
    cursor.execute("SELECT user_name, id from users where id=" + str(user['userId']))
    result=cursor.fetchone()

    filePath = str(pathlib.Path(__file__).parent.absolute()) + '\\UserSchema\\' + result[0] + '.xml'

    return send_file(filePath, as_attachment=True)

@app.route('/apiSchema/downloadRDF')
def downloadRDF():
    user = ValidateJWT()
    if user == None: 
        return '{"status": -1, "message": "not authorized"}', 401

    cursor = mydb.cursor()
    cursor.execute("SELECT user_name, id from users where id=" + str(user['userId']))
    result=cursor.fetchone()

    filePath = str(pathlib.Path(__file__).parent.absolute()) + '\\UserSchema\\' + result[0] + '.rdf'

    return send_file(filePath, as_attachment=True)

@app.route('/apiSchema/downloadHTML')
def downloadHTML():
    user = ValidateJWT()
    if user == None: 
        return '{"status": -1, "message": "not authorized"}', 401

    cursor = mydb.cursor()
    cursor.execute("SELECT user_name, id from users where id=" + str(user['userId']))
    result=cursor.fetchone()

    filePath = str(pathlib.Path(__file__).parent.absolute()) + '\\UserSchema\\' + result[0] + '.html'

    return send_file(filePath, as_attachment=True)

@app.route('/apiSchema/getUserSchemas')
def getUserSchemas():
    user = ValidateJWT()
    if user == None: 
        return '{"status": -1, "message": "not authorized"}', 401
    
    cursor = mydb.cursor()
    cursor.execute("SELECT user_name, id from users where id=" + str(user['userId']))
    result=cursor.fetchone()

    user_schemas = []
    try:
        for schema in ut.readXML_get_SchemaID(result[0]):
            dict_schema = {"name": schema[0], "id": schema[1]}
            user_schemas.append(dict_schema)

        return json.dumps(user_schemas)
    except: 
        return '{"status": -1, "message": ""}', 400

@app.route('/apiSchema/getUserSchema/<name>/<id>', methods=['GET'])
def getUserSchema(name, id):
    user = ValidateJWT()
    if user == None: 
        return '{"status": -1, "message": "not authorized"}', 401
    
    cursor = mydb.cursor()
    cursor.execute("SELECT user_name, id from users where id=" + str(user['userId']))
    result=cursor.fetchone()

    try:
        attrs = []
        result_dict = ut.getContent_schemaId(result[0], id, name)

        for attr in result_dict.keys():
            attrs.append({"name": attr, "type": result_dict.get(attr)[0], "value": result_dict.get(attr)[1]})

        return json.dumps(attrs)
    except:
        return '{"status": -1, "message": ""}', 400

#=== UTILS ==================
def CreateJWT(userId):
    return jwt.encode({'expTime': datetime.now().timestamp() ,'userId': userId}, jwtSecrete, algorithm='HS256')

def ValidateJWT():
    token = request.headers['Authorization']
    jwtStr = token.replace('Bearer ','')
    jwtBytes = jwtStr.encode("utf-8")
    
    try:
        user = jwt.decode(jwtBytes, jwtSecrete, algorithms=['HS256'])
    except:
        return None

    if datetime.now().timestamp() - user['expTime'] > 86400:
        return None

    cursor = mydb.cursor()
    cursor.execute("SELECT COUNT(*) from users where id=" + str(user['userId']))
    result=cursor.fetchone()
    if result[0] == 0:
        return None

    return user

def hash(text):
    sha512 = hashlib.sha512()
    sha512.update(text)
    return sha512.hexdigest().upper()

def schemaExist(schemaId, user):
    try:
        for schema in ut.readXML_get_SchemaID(user):
            if schema[1] == schemaId:
                return True
    except:
        return False
    return False

if __name__ == '__main__':
    cursor = mydb.cursor()
    tables = []

    cursor.execute("SHOW TABLES")

    for x in cursor:
        tables.append(x[0])

    if (not tables.__contains__('users')):
        cursor.execute("CREATE TABLE users (id INT AUTO_INCREMENT PRIMARY KEY, user_name VARCHAR(50), email VARCHAR(100), password TEXT)")

    app.run(debug=True, host="0.0.0.0", port=5000)