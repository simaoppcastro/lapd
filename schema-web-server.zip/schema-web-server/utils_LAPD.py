#!/usr/bin/env python
# coding: utf-8

from __future__ import unicode_literals
import os
from lxml import etree as et
from lxml import etree
from io import StringIO, BytesIO
from xml.etree import ElementTree as ET
import pandas as pd
import dicttoxml as Dxml
from xml.dom.minidom import parseString
from os import listdir
from os.path import isfile, join
import os.path as path
import shutil
# import xmltodict
# from datetime import datetime
# from jsonschema import validate
# import numpy as np
# import mysql.connector
# import xml.dom.minidom
# from random import randint
# import collections
# import numbers
# import logging
# import schemaorg as sc
# # import unicode as unicode
# from random import randint
# import collections
# import numbers
# import logging
# # from xml.dom.minidom import parseString
# from marshmallow import Schema, fields, pprint
# from datetime import date
# import csv


# return the result of the qery to the csv file
def openCSVfile(csv_input, column1_describe, column2_describe, *column3_describe):
    CSVresult = pd.read_csv(csv_input, usecols=[column1_describe, column2_describe, *column3_describe], squeeze = True, header = 0)
    return CSVresult

# return the result of the qery to the csv file
def GetSchemaList(csv_input, column1_describe, column2_describe, *column3_describe):
    CSVresult = pd.read_csv(csv_input, usecols=[column1_describe, column2_describe, *column3_describe], squeeze = True, header = 0)
    ListResult = pdSeriesToList(CSVresult)
    SchemaList = ListResult[1][0]
    return SchemaList

# with the result from the query of the csv file (pandas dataframe), create a list of list´s with the results
def pdSeriesToList(pdDataframe):
    idNumberList = pdDataframe['idNumber'].values.tolist()
    # return idList
    labelList = pdDataframe['label'].values.tolist()
    # return labelList
    propertiesList = pdDataframe['properties'].values.tolist()
    # return propertiesList
    ListResult = [[idNumberList], [labelList], [propertiesList]]
    return ListResult

# for debug
def printSpecifResult(pdDataframe, type_describe):
    for typeSeries in pdDataframe:
        if typeSeries == type_describe:
            print('type check' + ', ' + type_describe)

# method to get the different properties from the choosen class
def GetProperties(CSVresult, typeInput):
    PropertiesListOut = []
    ListResult = pdSeriesToList(CSVresult)
    idNumberList = ListResult[0][0]
    labelList = ListResult[1][0]
    propertiesList = ListResult[2][0]

    for id in idNumberList:
        try:
            # print(labelList[id])
            if labelList[id] == typeInput:
                # print(id)
                # print(labelList[id])
                # print(propertiesList[id])

                str_remove = 'http://schema.org/'
                properties_out = propertiesList[id].split(", ")

                for p_out in properties_out:
                    p = p_out.replace(str_remove, '')
                    # debug
                    # print(p)
                    PropertiesListOut.append(p)

        except:
            break

    return PropertiesListOut

# to create List of values
def CreateListValues(numberElements):
    ValuesList = numberElements* [None]
    return ValuesList

def GetValuesandTypes(PropertiesList):
    ValuesListout = CreateListValues(len(PropertiesList))
    dataTypeListout = CreateListValues(len(PropertiesList))
    ListOut = []

    for p in PropertiesList:
        # print(p + ": ")
        value = input(p + ": ")
        type = input("want specified type value? ")
        # print(value)
        if value != "":
            ValuesListout[PropertiesList.index(p)] = value
            # print()
        else:
            ValuesListout[PropertiesList.index(p)] = None

        if type != "":
            dataTypeListout[PropertiesList.index(p)] = type
            # print()
        else:
            dataTypeListout[PropertiesList.index(p)] = None

    ListOut.append(ValuesListout)
    ListOut.append(dataTypeListout)

    return ListOut

def GetValues(PropertiesList):
    ValuesListout = CreateListValues(len(PropertiesList))
    dataTypeListout = CreateListValues(len(PropertiesList))
    ListOut = []

    for p in PropertiesList:
        # print(p + ": ")
        value = input(p + ": ")
        type = input("want specified type value? ")
        # print(value)
        if value != "":
            ValuesListout[PropertiesList.index(p)] = value
            # print()
        else:
            ValuesListout[PropertiesList.index(p)] = None

        if type != "":
            dataTypeListout[PropertiesList.index(p)] = type
            # print()
        else:
            dataTypeListout[PropertiesList.index(p)] = None

    ListOut.append(ValuesListout)
    ListOut.append(dataTypeListout)

    return ListOut

# to get every label similar to the typeInput
def GetCompleteLabel(CSVresult, typeInput):
    ListType = []
    ListResult = pdSeriesToList(CSVresult)
    idNumberList = ListResult[0][0]
    labelList = ListResult[1][0]
    propertiesList = ListResult[2][0]
    flag = False

    for label in labelList:
        try:
            if typeInput in str(label):
                # print(label)
                # print(labelList.index(label))
                ListType.append(label)
        except:
            break

    return ListType

# for the creation of a dictionary from two list`s
def Dictionay(ListKeys, ListValues, userInput):
    # Dict = {'Schema': userInput}
    Dict = {}
    for key in ListKeys:
        Dict[key] = ListValues[ListKeys.index(key)]
        # print(Dict[key])
    '''
        for key in ListKeys:
        print(key)
        for value in ListValues:
            print(value)
            Dict[key] = value
    '''

    return Dict

######################################### XML methods ##########################################
# schema and ID names
# read xml file, and get every schema and ID that the specifc user have in the respectively XML
# return List of list with schema and ID, from the specific user
def readXML_get_SchemaID(userInput):
    parser = etree.XMLParser(remove_blank_text=True)
    xml = "UserSchema/" + userInput + ".xml"
    src = etree.parse(xml, parser)
    root = src.getroot()

    schemaList = []

    value2Remove1 = "{'ID': '"
    value2Remove2 = "'}"

    for child in root:
        schema = str(child.tag)
        id = str(child.attrib)
        id = id.replace(value2Remove1, '')
        id = id.replace(value2Remove2, '')
        schemaList.append([schema, id])
        # print(schema, id)

    # return List os lists with schema (key) and ID (value)
    return schemaList

# only schema names
# read xml file, and get every schema that the specifc user have
# return list of every schema from the specific user
def readXML_get_Schema(userInput):
    parser = etree.XMLParser(remove_blank_text=True)
    xml = "UserSchema/" + userInput + ".xml"
    src = etree.parse(xml, parser)
    root = src.getroot()

    schemaList = []
    for child in root:
        # print(child.tag)
        schemaList.append(child.tag)

    return schemaList

# pass to the function, user, id and schema that you want
# and the function returns one dict with key = propertie and value = [type, value]
def getContent_schemaId(userInput, idInput, schmaInput):
    list = readXML_get_SchemaID(userInput)
    Dict = {}
    flag = False
    for element1 in list:
       # print(element1[0], element1[1])
       if element1[0] == schmaInput and element1[1] == idInput:
           schema = element1[0]
           id = element1[1]
           flag = True
           break

    #print(schema, id, flag)
    value2Remove1 = "{'ID': '"
    value2Remove2 = "'}"

    if flag:
        # print(schema, id)
        parser = etree.XMLParser(remove_blank_text=True)
        xml = "UserSchema/" + userInput + ".xml"
        src = etree.parse(xml, parser)
        root = src.getroot()

        for child in root:
            temp = str(child.attrib)
            temp = temp.replace(value2Remove1, '')
            temp = temp.replace(value2Remove2, '')
            if (str(child.tag) == schema) and (temp == id):
                for element in child:
                    prop = str(element.tag)
                    type = str(element.attrib)
                    type = type.replace("{'type': '", '')
                    type = type.replace("'}", '')
                    value = str(element.text)
                    # debug
                    # print(prop, type, value)
                    Dict[prop] = [type, value]

    return Dict

# from a dictionary, create a xml file
def Dict_to_XML(Dict, userInput, typeInput, dataTypeList):
    xml_name = "xml/schema_" + userInput + "_" + typeInput + ".xml"
    # xml_name = "xml/schema_" + userInput + ".xml"

    if not os.path.exists(xml_name):
        with open(xml_name, 'w'): pass

    # create a bytes-xml object
    # xml = Dxml.dicttoxml(Dict, custom_root = userInput)
    xml = dicttoxml_extended(Dict, custom_root = userInput, second_root = typeInput)

    # organize information in "xml"
    ident_xml = parseString(xml).toprettyxml()

    # save it to disk
    fh = open(xml_name, "w")
    fh.write(ident_xml)
    fh.close()

    # return xml file
    return ident_xml

# add ID for the type specified for the user
def addID2Schema(idInput, fileInput, schemaInput):
    # parser = ET.XMLParser(remove_blank_text=True)
    # src_tree = ET.parse(fileInput)

    # element = src_tree.find(schemaInput).text
    # print(element)

    tree = ET.parse(fileInput)
    element = tree.find(schemaInput)

    # print(element)

    element.set("ID", idInput)
    # element.set("type", 'null')

    tree.write(fileInput, xml_declaration=True, encoding='utf-8', method="xml")

    # src_tree.write(fileInput, pretty_print=True, encoding='utf-8', xml_declaration=True)

# method to specified the data type of the value for every property
def addChangeType2XML(dataTypeList, fileInput):
    ListElement = []
    tree = ET.parse(fileInput)
    root = tree.getroot()
    for element in root.iter():
        # debug
        # print(element)
        ListElement.append(element)

    for p in ListElement[2:]:               # ListElement[1:]
         # element = tree.find(p)
         type = dataTypeList[ListElement.index(p) - 2]
         # debug
         # print(p)
         # print(type)

         if type != None:
             # debug
             # print(type)
             # print(p + ", " + type)
             p.set('type', type)
         else:
             type = "Null"
             # debug
             # print(type)
             # print(p + ", " + type)
             p.set('type', type)

         '''try:
             # type = dataTypeList[ListElement.index(p) - 2]
             # debug
             # print(p + ", " + type)
             # print(p)
             # print(type)
             p.set('type', type)
         except:
             print("Error")
             # type = None
             # debug
             # print(p)
             # print(type)
             # p.set('type', type)'''

    tree.write(fileInput, xml_declaration=True, encoding='utf-8', method="xml")

# create final xml file
def xml2xml(path_temp, path_final):
    parser = et.XMLParser(remove_blank_text=True)

    if VerifyFileExist(path_temp):
        src_tree = et.parse(path_temp, parser)
        src_root = src_tree.getroot()

        for child in src_root[0:1]:
            src_tag = child
            # print(src_tag)

    if VerifyFileExist(path_final) and VerifyFileExist(path_temp):
        dest_tree = et.parse(path_final, parser)
        dest_root = dest_tree.getroot()

        for child in dest_root[0:1]:
            dest_tag = child
            # print(dest_tag)

        dest_root.append(src_tag)
        et.ElementTree(dest_root).write(path_final, pretty_print=True, encoding='utf-8', xml_declaration=True)
        try:
            deleteXMLfile(path_temp)
        except:
            print()
    else:
        # create file
        src_tree = et.parse(path_temp, parser)
        src_root = src_tree.getroot()
        et.ElementTree(src_root).write(path_final, pretty_print=True, encoding='utf-8', xml_declaration=True)
        try:
            deleteXMLfile(path_temp)
        except:
            print()

    # dest_root.append(src_tag)

    # et.ElementTree(dest_root).write(destFilenamePathFinal, pretty_print=True, encoding='utf-8', xml_declaration=True)

# add docktype xml line config
def dockTypeInsert(userInput, fileInput, typeDock):
    check = False
    try:
        with open(fileInput) as f:
            if typeDock in f.read():
                check = True
    except:
        print("FileNotFoundError: [Errno 2] No such file or directory:")

    # debug
    # print(check)

    try:
        if not check:
            tree = etree.parse(fileInput)
            # print(etree.tostring(tree, xml_declaration=True, pretty_print=True, doctype=typeDock))
            # with open("xml/" + userInput + "_.xml", 'wb') as f:
            #     f.write(etree.tostring(tree, xml_declaration=True, pretty_print=True, doctype=typeDock))
            # wb -> write bytes

            with open(fileInput, 'wb') as f:
                f.write(
                    etree.tostring(tree, xml_declaration=True, pretty_print=True, doctype=typeDock, encoding='utf-8'))
        else:
            print("DocType already exists!")

        return True
    except:
        return False

# old method
# to add XML schema declaration
def nameSpaceDeclaration_old(userInput):
    xmlInput = "UserSchema/" + userInput + ".xml"
    xmlSchemaDec = userInput + " xmlns:xsi = 'http://www.w3.org/2001//XMLSchema-instance' xsi:noNamespaceSchemaLocation = '" + userInput + ".xsd'>"
    # debug
    # print(xmlInput)
    # print(xmlSchemaDec)

    tree = ET.parse(xmlInput)
    root = tree.getroot()
    # debug
    # print(root.tag)
    root.tag = xmlSchemaDec
    # print(root.tag)

    tree.write(xmlInput)

# to add XML schema declaration
def nameSpaceDeclaration(userInput):
    xmlInput = "UserSchema/" + userInput + ".xml"
    xmlOutput = "xml/" + userInput + ".xml"
    tag = "<" + userInput + ">"
    xmlSchemaDec = "<" + userInput + " xmlns:xsi = 'http://www.w3.org/2001//XMLSchema-instance' xsi:noNamespaceSchemaLocation = '" + userInput + ".xsd'>"

    try:
        fin = open(xmlInput, "rt")
        fout = open(xmlOutput, "wt")

        for line in fin:
            fout.write(line.replace(tag, xmlSchemaDec))

        fin.close()
        fout.close()

        try:
            moveFile(xmlOutput, xmlInput)
        except:
            print("Error moving Files")

        return True
    except:
        return False

# from xml, create a xsd file (XML schema)
def xml2xsd(userInput):
    xmlInput = "UserSchema/" + userInput + ".xml"
    # print(xmlInput)
    # https://docs.microsoft.com/en-us/dotnet/standard/serialization/xml-schema-definition-tool-xsd-exe
    # CMD /C – execute a command and then terminate
    # CMD /K – execute a command and then remain
    # command = 'cmd /C ./xsd .\\xsd\\' + xmlInput
    try:
        command = 'F:\Dropbox\Dir_simaoppcastro\Eng\Mestrado\\1ano\LingAnotacaoProcessamentoDoc\Project_LAPD\Project_LAPD\\00_Core\\UserSchema\\xsd.exe ' + xmlInput
        # debug
        # print(command)
        os.system(command)
    except:
        print("XSD creation Error! (xml2xsd())")
        # print(command)

    try:
        # after create xsd file, move it to the specific dir
        originDir = userInput + ".xsd"
        DestDir = "UserSchema/" + userInput + ".xsd"
        moveFile(originDir, DestDir)
    except:
        print("Error moving xsd file from dir2dir (moveFile())")
        print("Origin: " + originDir)
        print("Destiny: " + DestDir)

    try:
        # to control _app1.xsd
        orginDir2 = userInput + "_app1.xsd"
        DestDir2 = "UserSchema/" + userInput + "_app1.xsd"
        moveFile(orginDir2, DestDir2)
    except:
        print("Error moving xsd file from dir2dir (moveFile())")
        print("Origin: " + orginDir2)
        print("Destiny: " + DestDir2)

# to move files from one dir to another
def moveFile(originDir, DestDir):
    shutil.move(originDir, DestDir)
    # shutil.move(os.path.join(originDir, filename), os.path.join(DestDir, filename))

#XSL file
# to create the xsl/xslt file
# this creates one html for every schemaInput that exists in XML from the user
def htmlRuler_generator(userInput, schemaInput):
    rulerMaster = "UserSchema/XSLstyleSheetRules.xsl"
    h2Title = '    <h2>' + userInput + "_" + schemaInput + '</h2>\n'
    h2Comp = '    <h2>Schema</h2>\n'
    foreachSelector = "      <xsl:for-each select = '" + userInput + "/" + schemaInput + "/*'" + ">\n"
    foreachComp = '      <xsl:for-each select="Simao/Person/*">\n'
    outputXSLfile = "UserSchema/" + userInput + ".xsl"

    # debug
    # print(rulerMaster)
    # print(h2Title)
    # print(foreachSelector)
    # print(foreachComp)

    with open(rulerMaster, 'r') as f:
        content = f.readlines()
        # print(content)
        # print(type(content))
        for line in content:
            # print(line)
            if line == foreachComp:
                # print("True")
                content[content.index(line)] = foreachSelector
            elif line == h2Comp:
                content[content.index(line)] = h2Title

        # print(content)

    with open(outputXSLfile, "w+") as fo:
        fo.writelines(content)

# to create the xsl/xslt file (old method)
def htmlRuler_generator_old(userInput, schemaInput):
    rulerMaster = "UserSchema/XSLstyleSheetRules.xsl"
    h2Title = '    <h2>' + userInput + "_" + schemaInput + '</h2>\n'
    h2Comp = '    <h2>Schema</h2>\n'
    foreachSelector = "      <xsl:for-each select = '" + userInput + "/" + schemaInput + "/*'" + ">\n"
    foreachComp = '      <xsl:for-each select="Simao/Person/*">\n'
    outputXSLfile = "UserSchema/" + userInput + ".xsl"

    # debug
    # print(rulerMaster)
    # print(h2Title)
    # print(foreachSelector)
    # print(foreachComp)

    with open(rulerMaster, 'r') as f:
        content = f.readlines()
        # print(content)
        # print(type(content))
        for line in content:
            # print(line)
            if line == foreachComp:
                # print("True")
                content[content.index(line)] = foreachSelector
            elif line == h2Comp:
                content[content.index(line)] = h2Title

        # print(content)

    with open(outputXSLfile, "w+") as fo:
        fo.writelines(content)

#HTML file
# to create the html file
def XHTML_generator(userInput, schemaInput):
    # tree = ET
    # first create the xsl from the ruler base
    htmlRuler_generator(userInput, schemaInput)
    path_xml = "UserSchema/" + userInput + ".xml"
    path_xslt = "UserSchema/" + userInput + ".xsl"


    dom = etree.parse(path_xml)
    xslt = etree.parse(path_xslt)
    transform = etree.XSLT(xslt)
    html = transform(dom)
    # tree.parse(etree.tostring(html, pretty_print=True))
    # print(etree.tostring(html, pretty_print=True))
    # etree.write(etree.tostring(newdom, pretty_print=True))
    outputHtml = "UserSchema/" + userInput + ".html"

    if (path.exists(outputHtml)):
        deleteFile(outputHtml)

    html.write(outputHtml, encoding='utf-8', pretty_print=True, xml_declaration=True)

#RDF file
# from xml and xslt, generate RDF file
def xml_xslt2rdf(userInput):
    path_xml = "UserSchema/" + userInput + ".xml"
    path_xslt = "UserSchema/rulerXML2RDF" + ".xslt"

    dom = etree.parse(path_xml)
    xslt = etree.parse(path_xslt)
    transform = etree.XSLT(xslt)
    rdf = transform(dom)
    # debug
    # tree.parse(etree.tostring(html, pretty_print=True))
    # print(etree.tostring(html, pretty_print=True))
    # etree.write(etree.tostring(newdom, pretty_print=True))

    # this will update rdf file
    outputRDF = "UserSchema/" + userInput + ".rdf"

    if (path.exists(outputRDF)):
        deleteFile(outputRDF)

    rdf.write(outputRDF, encoding='utf-8', pretty_print=True)

# utils
# return all the name files in a specific path (input of the function)
def listFileDir(path):
    ListFilesOut = [f for f in listdir(path) if isfile(join(path, f))]

    return ListFilesOut

# utils
# so see if a Dir exists
# not used for now
def ConfirmDir(DirPath):
    # dirExist = os.path.isdir('./xml')

    if os.path.isdir(DirPath):
        return True
    else:
        return False

# utils
# to verify if a specif file (pathInput) exists
def VerifyFileExist(pathInput):
    if path.exists(pathInput):
        return True
    else:
        return False

# utils
# to delete a specifc file (xmlFile_inputPath)
def deleteXMLfile(xmlFile_inputPath):
    try:
        os.remove(xmlFile_inputPath)
    except:
        print("File does not exist!")

# to delete a generic file
def deleteFile(xmlFile_inputPath):
    try:
        os.remove(xmlFile_inputPath)
        return True
    except:
        print("File does not exist!")
        return False

###################################################################################################

# main method
def main_core():
    CompleteList = []

    CSVresult = openCSVfile('schema_csv/schema-types.csv', 'idNumber', 'label', 'properties')

    userInput = input("Username: ")
    typeInput = input("Choose Type: ")
    # teste impllementation of addID2Schema()
    idSchema = input("ID Type Name: ")

    # to get every label similar to the typeInput
    ListType = GetCompleteLabel(CSVresult, typeInput)
    # debug
    # print(ListType)
    # print(len(ListType))

    ########################################################################
    while not (len(ListType) == 1):
        typeInput = input("Choose Type: ")
        idSchema = input("ID Type Name: ")
        ListType = GetCompleteLabel(CSVresult, typeInput)
        # debug
        # print(ListType)
        # print(len(ListType))

        # continue

    if len(ListType) == 1:
        PropertiesList = GetProperties(CSVresult, ListType[0])

        # debug
        # print(ListType)

        # need work - in development
        # ValuesList = len(PropertiesList) * [None]
        # ValuesList = CreateListValues(len(PropertiesList))
        ValuesTypesList = GetValues(PropertiesList)
        ValuesList = ValuesTypesList[0]
        # print(ValuesList)

        # not used for now - future, user can choose the type (str, int) of the value corrsespondent to the property
        # ready - in tests - in beginnig type is set to str, after that,
        # addChangeType2XML() is called to set the type inputed for the user
        dataTypeList = ValuesTypesList[1]
        # print(dataTypeList)
        # print(ValuesList)

        # Dicitionary
        # print("Dicitionary:")
        Dict = Dictionay(PropertiesList, ValuesList, userInput)
        # Dict contains properties name and the value
        # debug
        # print(Dict)
        # print(ListType[0])
        # ListType[0] = schema
        # print(dataTypeList)
        # dataTypeList = list of the type of the value from the properties

        # XML
        xml = Dict_to_XML(Dict, userInput, ListType[0], dataTypeList)
        # print(xml)



    ########################################################################
    # teste impllementation of addID2Schema()
    PathInput = "xml/schema_" + userInput + "_" + typeInput + ".xml"
    addID2Schema(idSchema, PathInput, typeInput)

    # teste implementation of addChangeType2XML()
    addChangeType2XML(dataTypeList, PathInput)
    ########################################################################

    CompleteList.append(xml)
    CompleteList.append(Dict)
    CompleteList.append(CSVresult)
    CompleteList.append(PropertiesList)
    CompleteList.append(ValuesList)
    CompleteList.append(ListType)
    CompleteList.append(dataTypeList)

    # to create the final xml file from user
    path_final = 'UserSchema/' + userInput + '.xml'
    try:
        # path_final = 'xml/UserSchema/' + userInput + '.xml'
        xml2xml(PathInput, path_final)
    except:
        print("Error! xml2xml()")

    # to insert typeDock declaration (DTD validation)
    typeDock = "<!DOCTYPE " + userInput + " SYSTEM " + "'schemaDTD.dtd'>"
    # xmlSchemaDec = "xmlns:xsi = 'http://www.w3.org/2001//XMLSchema-instance' xsi:noNamespaceSchemaLocation = '" + userInput + ".xsd'>"
    # debug
    # print(xmlSchemaDec)

    # to add docktype declaration (DTD)
    try:
        # debug
        # print()
        # return bool
        flag_dock = dockTypeInsert(userInput, path_final, typeDock)
    except:
        print("Error! dockTypeInsert()")

    # to add the XML Schema declaration to the root element
    if flag_dock:
        try:
            # XML Schema file creation (return bool)
            flag_nameSpace = nameSpaceDeclaration(userInput)
        except:
            print("Error adding nameSpace XML Schema")

    # to create the XML Schema (.xsd file)
    if flag_nameSpace:
        try:
            xml2xsd(userInput)
        except:
            print("Error! xml2xsd()")

    # first generates the xsl/xslt file
    # second generates the html page with the content from the current user, and
    # the values for the specific schema with all the properties
    # and values
    XHTML_generator(userInput, typeInput)
    # from one xml and xslt file, generates a rdf file
    xml_xslt2rdf(userInput)

    return CompleteList

# to GET all current objects
class GET:

    def GetXML(self, main_init):
        return main_init[0]

    def GetDICT(self, main_init):
        return main_init[1]

    def GetCSVresult(self, main_init):
        return main_init[2]

    def GetPropertiesLIST(self, main_init):
        return main_init[3]

    def GetValuesLIST(self, main_init):
        return main_init[4]

    def GetListTYPES(self, main_init):
        return main_init[5]


################################# Dict to XML aux functions #################################################
'''
LOG = logging.getLogger("dicttoxml")


# python 3 doesn't have a unicode type
try:
    unicode
except:
    unicode = str

# python 3 doesn't have a long type
try:
    long
except:
    long = int

unicode = str
long = int

def set_debug(debug=True, filename='dicttoxml.log'):
    if debug:
        import datetime
        print('Debug mode is on. Events are logged at: %s' % (filename))
        logging.basicConfig(filename=filename, level=logging.INFO)
        LOG.info('\nLogging session starts: %s' % (
            str(datetime.datetime.today()))
                 )
    else:
        logging.basicConfig(level=logging.WARNING)
        print('Debug mode is off.')


def unicode_me(something):
    """Converts strings with non-ASCII characters to unicode for LOG.
    Python 3 doesn't have a `unicode()` function, so `unicode()` is an alias
    for `str()`, but `str()` doesn't take a second argument, hence this kludge.
    """
    try:
        return unicode(something, 'utf-8')
    except:
        return unicode(something)


ids = []  # initialize list of unique ids


def make_id(element, start=100000, end=999999):
    """Returns a random integer"""
    return '%s_%s' % (element, randint(start, end))


def get_unique_id(element):
    """Returns a unique id for a given element"""
    this_id = make_id(element)
    dup = True
    while dup:
        if this_id not in ids:
            dup = False
            ids.append(this_id)
        else:
            this_id = make_id(element)
    return ids[-1]


def get_xml_type(val):
    """Returns the data type for the xml type attribute"""
    if type(val).__name__ in ('str', 'unicode'):
        return 'str'
    if type(val).__name__ in ('int', 'long'):
        return 'int'
    if type(val).__name__ == 'float':
        return 'float'
    if type(val).__name__ == 'bool':
        return 'bool'
    if isinstance(val, numbers.Number):
        return 'number'
    if type(val).__name__ == 'NoneType':
        return 'null'
    if isinstance(val, dict):
        return 'dict'
    if isinstance(val, collections.Iterable):
        return 'list'
    return type(val).__name__


def escape_xml(s):
    if type(s) in (str, unicode):
        s = unicode_me(s)  # avoid UnicodeDecodeError
        s = s.replace('&', '&amp;')
        s = s.replace('"', '&quot;')
        s = s.replace('\'', '&apos;')
        s = s.replace('<', '&lt;')
        s = s.replace('>', '&gt;')
    return s


def make_attrstring(attr):
    """Returns an attribute string in the form key="val" """
    attrstring = ' '.join(['%s="%s"' % (k, v) for k, v in attr.items()])
    return '%s%s' % (' ' if attrstring != '' else '', attrstring)


def key_is_valid_xml(key):
    """Checks that a key is a valid XML name"""
    LOG.info('Inside key_is_valid_xml(). Testing "%s"' % (unicode_me(key)))
    test_xml = '<?xml version="1.0" encoding="UTF-8" ?><%s>foo</%s>' % (key, key)
    try:
        parseString(test_xml)
        return True
    except Exception:  # minidom does not implement exceptions well
        return False


def make_valid_xml_name(key, attr):
    """Tests an XML name and fixes it if invalid"""
    LOG.info('Inside make_valid_xml_name(). Testing key "%s" with attr "%s"' % (
        unicode_me(key), unicode_me(attr))
             )
    key = escape_xml(key)
    attr = escape_xml(attr)

    # pass through if key is already valid
    if key_is_valid_xml(key):
        return key, attr

    # prepend a lowercase n if the key is numeric
    if key.isdigit():
        return 'n%s' % (key), attr

    # replace spaces with underscores if that fixes the problem
    if key_is_valid_xml(key.replace(' ', '_')):
        return key.replace(' ', '_'), attr

    # key is still invalid - move it into a name attribute
    attr['name'] = key
    key = 'key'
    return key, attr


def wrap_cdata(s):
    """Wraps a string into CDATA sections"""
    s = unicode_me(s).replace(']]>', ']]]]><![CDATA[>')
    return '<![CDATA[' + s + ']]>'


def default_item_func(parent):
    return 'item'


def convert(obj, ids, ListType, attr_type, item_func, cdata, parent='root'):
    """Routes the elements of an object to the right function to convert them
    based on their data type"""

    LOG.info('Inside convert(). obj type is: "%s", obj="%s"' % (type(obj).__name__, unicode_me(obj)))

    item_name = item_func(parent)

    if isinstance(obj, numbers.Number) or type(obj) in (str, unicode):
        return convert_kv(item_name, obj, attr_type, cdata)

    if hasattr(obj, 'isoformat'):
        return convert_kv(item_name, obj.isoformat(), attr_type, cdata)

    if type(obj) == bool:
        return convert_bool(item_name, obj, attr_type, cdata)

    if obj is None:
        return convert_none(item_name, '', attr_type, cdata)

    if isinstance(obj, dict):
        return convert_dict(obj, ids, ListType, parent, attr_type, item_func, cdata)

    if isinstance(obj, collections.Iterable):
        return convert_list(obj, ids, parent, attr_type, item_func, cdata)

    raise TypeError('Unsupported data type: %s (%s)' % (obj, type(obj).__name__))


def convert_dict(obj, ids, ListType, parent, attr_type, item_func, cdata):
    """Converts a dict into an XML string."""
    LOG.info('Inside convert_dict(): obj type is: "%s", obj="%s"' % (
        type(obj).__name__, unicode_me(obj))
             )
    output = []
    addline = output.append

    item_name = item_func(parent)

    for key, val in obj.items():
        LOG.info('Looping inside convert_dict(): key="%s", val="%s", type(val)="%s"' % (
            unicode_me(key), unicode_me(val), type(val).__name__)
                 )

        attr = {} if not ids else {'id': '%s' % (get_unique_id(parent))}

        key, attr = make_valid_xml_name(key, attr)

        if isinstance(val, numbers.Number) or type(val) in (str, unicode):
            addline(convert_kv(key, val, attr_type, attr, cdata))

        elif hasattr(val, 'isoformat'):  # datetime
            addline(convert_kv(key, val.isoformat(), attr_type, attr, cdata))

        elif type(val) == bool:
            addline(convert_bool(key, val, attr_type, attr, cdata))

        elif isinstance(val, dict):
            if attr_type:
                # attr['type'] = get_xml_type(val)
                # debug
                print(ListType[key])
                attr['type'] = ListType[key]
            addline('<%s%s>%s</%s>' % (
                key, make_attrstring(attr),
                convert_dict(val, ids, key, attr_type, item_func, cdata),
                key
            )
                    )

        elif isinstance(val, collections.Iterable):
            if attr_type:
                # attr['type'] = get_xml_type(val)
                # debug
                print(ListType[key])
                attr['type'] = ListType[key]
            addline('<%s%s>%s</%s>' % (
                key,
                make_attrstring(attr),
                convert_list(val, ids, key, attr_type, item_func, cdata),
                key
            )
                    )

        elif val is None:
            addline(convert_none(key, val, attr_type, attr, cdata))

        else:
            raise TypeError('Unsupported data type: %s (%s)' % (
                val, type(val).__name__)
                            )

    return ''.join(output)


def convert_list(items, ids, parent, attr_type, item_func, cdata):
    """Converts a list into an XML string."""
    LOG.info('Inside convert_list()')
    output = []
    addline = output.append

    item_name = item_func(parent)

    if ids:
        this_id = get_unique_id(parent)

    for i, item in enumerate(items):
        LOG.info('Looping inside convert_list(): item="%s", item_name="%s", type="%s"' % (
            unicode_me(item), item_name, type(item).__name__)
                 )
        attr = {} if not ids else {'id': '%s_%s' % (this_id, i + 1)}
        if isinstance(item, numbers.Number) or type(item) in (str, unicode):
            addline(convert_kv(item_name, item, attr_type, attr, cdata))

        elif hasattr(item, 'isoformat'):  # datetime
            addline(convert_kv(item_name, item.isoformat(), attr_type, attr, cdata))

        elif type(item) == bool:
            addline(convert_bool(item_name, item, attr_type, attr, cdata))

        elif isinstance(item, dict):
            if not attr_type:
                addline('<%s>%s</%s>' % (
                    item_name,
                    convert_dict(item, ids, parent, attr_type, item_func, cdata),
                    item_name,
                )
                        )
            else:
                addline('<%s type="dict">%s</%s>' % (
                    item_name,
                    convert_dict(item, ids, parent, attr_type, item_func, cdata),
                    item_name,
                )
                        )

        elif isinstance(item, collections.Iterable):
            if not attr_type:
                addline('<%s %s>%s</%s>' % (
                    item_name, make_attrstring(attr),
                    convert_list(item, ids, item_name, attr_type, item_func, cdata),
                    item_name,
                )
                        )
            else:
                addline('<%s type="list"%s>%s</%s>' % (
                    item_name, make_attrstring(attr),
                    convert_list(item, ids, item_name, attr_type, item_func, cdata),
                    item_name,
                )
                        )

        elif item is None:
            addline(convert_none(item_name, None, attr_type, attr, cdata))

        else:
            raise TypeError('Unsupported data type: %s (%s)' % (
                item, type(item).__name__)
                            )
    return ''.join(output)


def convert_kv(key, val, attr_type, attr={}, cdata=False):
    """Converts a number or string into an XML element"""
    LOG.info('Inside convert_kv(): key="%s", val="%s", type(val) is: "%s"' % (
        unicode_me(key), unicode_me(val), type(val).__name__)
             )

    key, attr = make_valid_xml_name(key, attr)

    if attr_type:
        attr['type'] = get_xml_type(val)
    attrstring = make_attrstring(attr)
    return '<%s%s>%s</%s>' % (
        key, attrstring,
        wrap_cdata(val) if cdata == True else escape_xml(val),
        key
    )


def convert_bool(key, val, attr_type, attr={}, cdata=False):
    """Converts a boolean into an XML element"""
    LOG.info('Inside convert_bool(): key="%s", val="%s", type(val) is: "%s"' % (
        unicode_me(key), unicode_me(val), type(val).__name__)
             )

    key, attr = make_valid_xml_name(key, attr)

    if attr_type:
        attr['type'] = get_xml_type(val)
    attrstring = make_attrstring(attr)
    return '<%s%s>%s</%s>' % (key, attrstring, unicode(val).lower(), key)


def convert_none(key, val, attr_type, attr={}, cdata=False):
    """Converts a null value into an XML element"""
    LOG.info('Inside convert_none(): key="%s"' % (unicode_me(key)))

    key, attr = make_valid_xml_name(key, attr)

    if attr_type:
        attr['type'] = get_xml_type(val)
    attrstring = make_attrstring(attr)
    return '<%s%s></%s>' % (key, attrstring, key)

'''


def dicttoxml_extended(obj, root=True, custom_root='root', second_root='subroot', ids=False, attr_type=True,
                       item_func=Dxml.default_item_func, cdata=False):
    """Converts a python object into XML.
    Arguments:
    - root specifies whether the output is wrapped in an XML root element
      Default is True
    - custom_root allows you to specify a custom root element.
      Default is 'root'
    - ids specifies whether elements get unique ids.
      Default is False
    - attr_type specifies whether elements get a data type attribute.
      Default is True
    - item_func specifies what function should generate the element name for
      items in a list.
      Default is 'item'
    - cdata specifies whether string values should be wrapped in CDATA sections.
      Default is False
    """
    Dxml.LOG.info('Inside dicttoxml(): type(obj) is: "%s", obj="%s"' % (type(obj).__name__, Dxml.unicode_me(obj)))
    output = []
    addline = output.append
    if root == True:
        addline('<?xml version="1.0" encoding="UTF-8" ?>')
        addline('<!DOCTYPE User SYSTEM "schema_DTD.dtd">')
        addline('<%s><%s>%s</%s></%s>' % (
            custom_root,
            second_root,
            Dxml.convert(obj, ids, attr_type, item_func, cdata, parent=custom_root),
            second_root,
            custom_root,
        )
                )
    else:
        addline(Dxml.convert(obj, ids, attr_type, item_func, cdata, parent=''))
    return ''.join(output).encode('utf-8')


#########################END of aux function for Dict_to_XML##################################################

